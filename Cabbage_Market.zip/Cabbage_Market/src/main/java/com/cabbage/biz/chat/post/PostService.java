package com.cabbage.biz.chat.post;

public interface PostService {
	
	PostVO getPostById(long postId);
	
}
