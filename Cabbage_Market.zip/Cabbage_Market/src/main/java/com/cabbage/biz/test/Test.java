package com.cabbage.biz.test;

public class Test {

	public static void main(String[] args) {
		String lastEventId = "jsw4795_1482323_room";
		String eventId = "jsw4795_1397461_chatMessage";
		
		System.out.println(lastEventId.compareTo(eventId));
	}

}
